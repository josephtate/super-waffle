__version__ = "0.1.0"

from .cloud_metadata import get_cloud_metadata
from .repo_config import select_mirror, build_repo_config

with open("/tmp/version_log.txt", "w") as f:
    f.write(f"VERSION: {__version__}\n")
